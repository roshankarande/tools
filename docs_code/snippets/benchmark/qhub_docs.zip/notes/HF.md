
```
pip install -U "huggingface_hub[cli]"
```

```

```


llama_v3_1_8b_chat_quantized

llama-v3-1-8b-chat-quantized

```
pip install -U "qai_hub_models[llama-v3-8b-chat-quantized]"

pip install -U "qai_hub_models[llama-v3-1-8b-chat-quantized]"
```


-----

QC HUB


https://app.aihub.qualcomm.com/docs/hub/getting_started.html


karande@qualcomm.com
```
pip install qai-hub  
qai-hub configure --api_token 

```

```
C:\Users\admin/.qai_hub/client.ini
/home/heyia/.qai_hub/client.ini
```

```
qai-hub list-devices
```


```
	python -m qai_hub_models.models.llama_v3_2_3b_chat_quantized.export --chipset qualcomm-snapdragon-x-elite --skip-inferencing --skip-profiling --output-dir genie_bundle

```




![[Pasted image 20241127110358.png]]

![[Pasted image 20241127144626.png]]


![[Pasted image 20241127144728.png]]

```
./genie-t2t-run.exe -c genie_config.json -p "<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\nWhat is France's capital? Answer elaborately<|eot_id|><|start_header_id|>assistant<|end_header_id|>"

```

C:\Qualcomm\AIStack\QAIRT\2.28.2.241116\examples\Genie\Genie\src\qualla

C:\Users\admin\Desktop\target\genie\ai-hub-apps\apps\windows\cpp\ChatApp

https://github.com/quic/wos-ai-demos
https://github.com/quic/wos-ai



--------------

3.2 1b

```

ai-hub-models -> clone it

uv pip install -e .

uv pip install -r C:\Users\admin\Desktop\target\genie\ai-hub-models\qai_hub_models\models\llama_v3_2_1b_chat_quantized\requirements.txt

python -m qai_hub_models.models.llama_v3_2_1b_chat_quantized.export --chipset qualcomm-snapdragon-x-elite  --output-dir genie_bundle 


```


https://quic.github.io/aimet-pages/AimetDocs/api_docs/quantization_encoding_specification.html